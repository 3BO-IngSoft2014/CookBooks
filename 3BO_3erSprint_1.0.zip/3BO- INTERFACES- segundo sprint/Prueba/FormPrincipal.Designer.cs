﻿namespace Prueba
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Usuario = new System.Windows.Forms.TextBox();
            this.Loggin = new System.Windows.Forms.Button();
            this.registrarse = new System.Windows.Forms.Button();
            this.lista_libros = new System.Windows.Forms.Button();
            this.mas_vendidos = new System.Windows.Forms.Button();
            this.add_libro = new System.Windows.Forms.Button();
            this.borrar_libro = new System.Windows.Forms.Button();
            this.agregar_aut = new System.Windows.Forms.Button();
            this.del_autor = new System.Windows.Forms.Button();
            this.eliminar_usuario = new System.Windows.Forms.Button();
            this.Agregar_FAQ = new System.Windows.Forms.Button();
            this.EstadoLoggin = new System.Windows.Forms.Label();
            this.Tabs = new System.Windows.Forms.TabControl();
            this.Home = new System.Windows.Forms.TabPage();
            this.busq_text = new System.Windows.Forms.TextBox();
            this.BUSCAR = new System.Windows.Forms.Button();
            this.Desloggear = new System.Windows.Forms.Button();
            this.dataGrid = new System.Windows.Forms.DataGridView();
            this.password = new System.Windows.Forms.TextBox();
            this.FAQ = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pregBox = new System.Windows.Forms.ComboBox();
            this.Elegir = new System.Windows.Forms.Button();
            this.GestorUsuarios = new System.Windows.Forms.TabPage();
            this.GestorLibros = new System.Windows.Forms.TabPage();
            this.GestorAutores = new System.Windows.Forms.TabPage();
            this.Stock = new System.Windows.Forms.TabPage();
            this.librosBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.sistemalibroscocinaDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sistema_libros_cocinaDataSet = new Prueba.sistema_libros_cocinaDataSet();
            this.librosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.librosTableAdapter = new Prueba.sistema_libros_cocinaDataSetTableAdapters.librosTableAdapter();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.libisbnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.libnombreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.libstockDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tabs.SuspendLayout();
            this.Home.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.FAQ.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.GestorUsuarios.SuspendLayout();
            this.GestorLibros.SuspendLayout();
            this.GestorAutores.SuspendLayout();
            this.Stock.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.librosBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemalibroscocinaDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistema_libros_cocinaDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.librosBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // Usuario
            // 
            this.Usuario.Location = new System.Drawing.Point(532, 36);
            this.Usuario.Name = "Usuario";
            this.Usuario.Size = new System.Drawing.Size(100, 20);
            this.Usuario.TabIndex = 0;
            this.Usuario.Text = "nombreUsuario";
            // 
            // Loggin
            // 
            this.Loggin.Location = new System.Drawing.Point(673, 20);
            this.Loggin.Name = "Loggin";
            this.Loggin.Size = new System.Drawing.Size(75, 23);
            this.Loggin.TabIndex = 2;
            this.Loggin.Text = "iniciar ";
            this.Loggin.UseVisualStyleBackColor = true;
            this.Loggin.Click += new System.EventHandler(this.Loggin_Click);
            // 
            // registrarse
            // 
            this.registrarse.Location = new System.Drawing.Point(673, 59);
            this.registrarse.Name = "registrarse";
            this.registrarse.Size = new System.Drawing.Size(75, 23);
            this.registrarse.TabIndex = 3;
            this.registrarse.Text = "Registrarse";
            this.registrarse.UseVisualStyleBackColor = true;
            this.registrarse.Click += new System.EventHandler(this.registrarse_Click);
            // 
            // lista_libros
            // 
            this.lista_libros.Location = new System.Drawing.Point(39, 129);
            this.lista_libros.Name = "lista_libros";
            this.lista_libros.Size = new System.Drawing.Size(135, 44);
            this.lista_libros.TabIndex = 4;
            this.lista_libros.Text = "ver lista de libros";
            this.lista_libros.UseVisualStyleBackColor = true;
            this.lista_libros.Click += new System.EventHandler(this.lista_libros_Click);
            // 
            // mas_vendidos
            // 
            this.mas_vendidos.Location = new System.Drawing.Point(230, 120);
            this.mas_vendidos.Name = "mas_vendidos";
            this.mas_vendidos.Size = new System.Drawing.Size(135, 53);
            this.mas_vendidos.TabIndex = 6;
            this.mas_vendidos.Text = "libros mas vendidos";
            this.mas_vendidos.UseVisualStyleBackColor = true;
            this.mas_vendidos.Click += new System.EventHandler(this.mas_vendidos_Click);
            // 
            // add_libro
            // 
            this.add_libro.Location = new System.Drawing.Point(55, 33);
            this.add_libro.Name = "add_libro";
            this.add_libro.Size = new System.Drawing.Size(107, 45);
            this.add_libro.TabIndex = 7;
            this.add_libro.Text = "agregar Libro";
            this.add_libro.UseVisualStyleBackColor = true;
            this.add_libro.Click += new System.EventHandler(this.add_libro_Click);
            // 
            // borrar_libro
            // 
            this.borrar_libro.Location = new System.Drawing.Point(209, 32);
            this.borrar_libro.Name = "borrar_libro";
            this.borrar_libro.Size = new System.Drawing.Size(119, 46);
            this.borrar_libro.TabIndex = 8;
            this.borrar_libro.Text = "borrar libro";
            this.borrar_libro.UseVisualStyleBackColor = true;
            this.borrar_libro.Click += new System.EventHandler(this.borrar_libro_Click);
            // 
            // agregar_aut
            // 
            this.agregar_aut.Location = new System.Drawing.Point(55, 43);
            this.agregar_aut.Name = "agregar_aut";
            this.agregar_aut.Size = new System.Drawing.Size(101, 57);
            this.agregar_aut.TabIndex = 9;
            this.agregar_aut.Text = "Agregar Autor";
            this.agregar_aut.UseVisualStyleBackColor = true;
            this.agregar_aut.Click += new System.EventHandler(this.agregar_aut_Click);
            // 
            // del_autor
            // 
            this.del_autor.Location = new System.Drawing.Point(205, 43);
            this.del_autor.Name = "del_autor";
            this.del_autor.Size = new System.Drawing.Size(102, 57);
            this.del_autor.TabIndex = 12;
            this.del_autor.Text = "borrar Autor";
            this.del_autor.UseVisualStyleBackColor = true;
            this.del_autor.Click += new System.EventHandler(this.del_autor_Click);
            // 
            // eliminar_usuario
            // 
            this.eliminar_usuario.Location = new System.Drawing.Point(272, 41);
            this.eliminar_usuario.Name = "eliminar_usuario";
            this.eliminar_usuario.Size = new System.Drawing.Size(117, 46);
            this.eliminar_usuario.TabIndex = 13;
            this.eliminar_usuario.Text = "eliminar Usuario";
            this.eliminar_usuario.UseVisualStyleBackColor = true;
            this.eliminar_usuario.Click += new System.EventHandler(this.eliminar_usuario_Click);
            // 
            // Agregar_FAQ
            // 
            this.Agregar_FAQ.Location = new System.Drawing.Point(414, 6);
            this.Agregar_FAQ.Name = "Agregar_FAQ";
            this.Agregar_FAQ.Size = new System.Drawing.Size(71, 36);
            this.Agregar_FAQ.TabIndex = 14;
            this.Agregar_FAQ.Text = "agregar FAQ";
            this.Agregar_FAQ.UseVisualStyleBackColor = true;
            this.Agregar_FAQ.Click += new System.EventHandler(this.Agregar_FAQ_Click);
            // 
            // EstadoLoggin
            // 
            this.EstadoLoggin.AutoSize = true;
            this.EstadoLoggin.Location = new System.Drawing.Point(524, 20);
            this.EstadoLoggin.Name = "EstadoLoggin";
            this.EstadoLoggin.Size = new System.Drawing.Size(108, 13);
            this.EstadoLoggin.TabIndex = 16;
            this.EstadoLoggin.Text = "Registrate o loggeate";
            // 
            // Tabs
            // 
            this.Tabs.Controls.Add(this.Home);
            this.Tabs.Controls.Add(this.FAQ);
            this.Tabs.Controls.Add(this.GestorUsuarios);
            this.Tabs.Controls.Add(this.GestorLibros);
            this.Tabs.Controls.Add(this.GestorAutores);
            this.Tabs.Controls.Add(this.Stock);
            this.Tabs.Location = new System.Drawing.Point(0, 2);
            this.Tabs.Name = "Tabs";
            this.Tabs.SelectedIndex = 0;
            this.Tabs.Size = new System.Drawing.Size(822, 467);
            this.Tabs.TabIndex = 17;
            this.Tabs.Layout += new System.Windows.Forms.LayoutEventHandler(this.Tabs_Layout);
            // 
            // Home
            // 
            this.Home.Controls.Add(this.busq_text);
            this.Home.Controls.Add(this.BUSCAR);
            this.Home.Controls.Add(this.Desloggear);
            this.Home.Controls.Add(this.registrarse);
            this.Home.Controls.Add(this.dataGrid);
            this.Home.Controls.Add(this.EstadoLoggin);
            this.Home.Controls.Add(this.Loggin);
            this.Home.Controls.Add(this.Usuario);
            this.Home.Controls.Add(this.password);
            this.Home.Location = new System.Drawing.Point(4, 22);
            this.Home.Name = "Home";
            this.Home.Padding = new System.Windows.Forms.Padding(3);
            this.Home.Size = new System.Drawing.Size(814, 441);
            this.Home.TabIndex = 0;
            this.Home.Text = "Home";
            this.Home.UseVisualStyleBackColor = true;
            this.Home.Enter += new System.EventHandler(this.Home_Enter);
            // 
            // busq_text
            // 
            this.busq_text.Location = new System.Drawing.Point(50, 20);
            this.busq_text.Name = "busq_text";
            this.busq_text.Size = new System.Drawing.Size(256, 20);
            this.busq_text.TabIndex = 21;
            // 
            // BUSCAR
            // 
            this.BUSCAR.Location = new System.Drawing.Point(329, 20);
            this.BUSCAR.Name = "BUSCAR";
            this.BUSCAR.Size = new System.Drawing.Size(102, 23);
            this.BUSCAR.TabIndex = 20;
            this.BUSCAR.Text = "BUSCAR";
            this.BUSCAR.UseCompatibleTextRendering = true;
            this.BUSCAR.UseVisualStyleBackColor = true;
            this.BUSCAR.Click += new System.EventHandler(this.BUSCAR_Click);
            // 
            // Desloggear
            // 
            this.Desloggear.Location = new System.Drawing.Point(673, 88);
            this.Desloggear.Name = "Desloggear";
            this.Desloggear.Size = new System.Drawing.Size(75, 23);
            this.Desloggear.TabIndex = 18;
            this.Desloggear.Text = "Cerrar Sesión";
            this.Desloggear.UseVisualStyleBackColor = true;
            this.Desloggear.Click += new System.EventHandler(this.Desloggear_Click);
            // 
            // dataGrid
            // 
            this.dataGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dataGrid.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dataGrid.BackgroundColor = System.Drawing.Color.Green;
            this.dataGrid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid.Location = new System.Drawing.Point(35, 79);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.Size = new System.Drawing.Size(365, 302);
            this.dataGrid.TabIndex = 1;
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(532, 62);
            this.password.MaxLength = 14;
            this.password.Name = "password";
            this.password.PasswordChar = '*';
            this.password.Size = new System.Drawing.Size(100, 20);
            this.password.TabIndex = 1;
            this.password.Text = "password";
            // 
            // FAQ
            // 
            this.FAQ.Controls.Add(this.dataGridView1);
            this.FAQ.Controls.Add(this.pregBox);
            this.FAQ.Controls.Add(this.Elegir);
            this.FAQ.Controls.Add(this.Agregar_FAQ);
            this.FAQ.Location = new System.Drawing.Point(4, 22);
            this.FAQ.Name = "FAQ";
            this.FAQ.Padding = new System.Windows.Forms.Padding(3);
            this.FAQ.Size = new System.Drawing.Size(814, 441);
            this.FAQ.TabIndex = 1;
            this.FAQ.Text = "FAQ";
            this.FAQ.UseVisualStyleBackColor = true;
            this.FAQ.Click += new System.EventHandler(this.FAQ_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 70);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(419, 255);
            this.dataGridView1.TabIndex = 5;
            // 
            // pregBox
            // 
            this.pregBox.FormattingEnabled = true;
            this.pregBox.Location = new System.Drawing.Point(3, 9);
            this.pregBox.Name = "pregBox";
            this.pregBox.Size = new System.Drawing.Size(285, 21);
            this.pregBox.TabIndex = 4;
            this.pregBox.Enter += new System.EventHandler(this.pregBox_Enter);
            this.pregBox.Leave += new System.EventHandler(this.pregBox_Leave);
            // 
            // Elegir
            // 
            this.Elegir.Location = new System.Drawing.Point(324, 3);
            this.Elegir.Name = "Elegir";
            this.Elegir.Size = new System.Drawing.Size(58, 23);
            this.Elegir.TabIndex = 3;
            this.Elegir.Text = "Elegir";
            this.Elegir.UseVisualStyleBackColor = true;
            this.Elegir.Click += new System.EventHandler(this.Elegir_Click);
            // 
            // GestorUsuarios
            // 
            this.GestorUsuarios.Controls.Add(this.eliminar_usuario);
            this.GestorUsuarios.Location = new System.Drawing.Point(4, 22);
            this.GestorUsuarios.Name = "GestorUsuarios";
            this.GestorUsuarios.Padding = new System.Windows.Forms.Padding(3);
            this.GestorUsuarios.Size = new System.Drawing.Size(814, 441);
            this.GestorUsuarios.TabIndex = 2;
            this.GestorUsuarios.Text = "Gestor Usuarios";
            this.GestorUsuarios.UseVisualStyleBackColor = true;
            // 
            // GestorLibros
            // 
            this.GestorLibros.Controls.Add(this.add_libro);
            this.GestorLibros.Controls.Add(this.borrar_libro);
            this.GestorLibros.Controls.Add(this.lista_libros);
            this.GestorLibros.Controls.Add(this.mas_vendidos);
            this.GestorLibros.Location = new System.Drawing.Point(4, 22);
            this.GestorLibros.Name = "GestorLibros";
            this.GestorLibros.Padding = new System.Windows.Forms.Padding(3);
            this.GestorLibros.Size = new System.Drawing.Size(814, 441);
            this.GestorLibros.TabIndex = 3;
            this.GestorLibros.Text = "Gestor Libros";
            this.GestorLibros.UseVisualStyleBackColor = true;
            // 
            // GestorAutores
            // 
            this.GestorAutores.Controls.Add(this.agregar_aut);
            this.GestorAutores.Controls.Add(this.del_autor);
            this.GestorAutores.Location = new System.Drawing.Point(4, 22);
            this.GestorAutores.Name = "GestorAutores";
            this.GestorAutores.Padding = new System.Windows.Forms.Padding(3);
            this.GestorAutores.Size = new System.Drawing.Size(814, 441);
            this.GestorAutores.TabIndex = 4;
            this.GestorAutores.Text = "Gestor Autores";
            this.GestorAutores.UseVisualStyleBackColor = true;
            // 
            // Stock
            // 
            this.Stock.Controls.Add(this.dataGridView2);
            this.Stock.Location = new System.Drawing.Point(4, 22);
            this.Stock.Name = "Stock";
            this.Stock.Padding = new System.Windows.Forms.Padding(3);
            this.Stock.Size = new System.Drawing.Size(814, 441);
            this.Stock.TabIndex = 5;
            this.Stock.Text = "Control de stock";
            this.Stock.UseVisualStyleBackColor = true;
            // 
            // librosBindingSource1
            // 
            this.librosBindingSource1.DataMember = "libros";
            this.librosBindingSource1.DataSource = this.sistemalibroscocinaDataSetBindingSource;
            // 
            // sistemalibroscocinaDataSetBindingSource
            // 
            this.sistemalibroscocinaDataSetBindingSource.DataSource = this.sistema_libros_cocinaDataSet;
            this.sistemalibroscocinaDataSetBindingSource.Position = 0;
            // 
            // sistema_libros_cocinaDataSet
            // 
            this.sistema_libros_cocinaDataSet.DataSetName = "sistema_libros_cocinaDataSet";
            this.sistema_libros_cocinaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // librosBindingSource
            // 
            this.librosBindingSource.DataMember = "libros";
            this.librosBindingSource.DataSource = this.sistemalibroscocinaDataSetBindingSource;
            // 
            // librosTableAdapter
            // 
            this.librosTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.libisbnDataGridViewTextBoxColumn,
            this.libnombreDataGridViewTextBoxColumn,
            this.libstockDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.librosBindingSource1;
            this.dataGridView2.Location = new System.Drawing.Point(79, 47);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(383, 261);
            this.dataGridView2.TabIndex = 0;
            // 
            // libisbnDataGridViewTextBoxColumn
            // 
            this.libisbnDataGridViewTextBoxColumn.DataPropertyName = "lib_isbn";
            this.libisbnDataGridViewTextBoxColumn.HeaderText = "ISBN";
            this.libisbnDataGridViewTextBoxColumn.Name = "libisbnDataGridViewTextBoxColumn";
            this.libisbnDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // libnombreDataGridViewTextBoxColumn
            // 
            this.libnombreDataGridViewTextBoxColumn.DataPropertyName = "lib_nombre";
            this.libnombreDataGridViewTextBoxColumn.HeaderText = "Titulo";
            this.libnombreDataGridViewTextBoxColumn.Name = "libnombreDataGridViewTextBoxColumn";
            this.libnombreDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // libstockDataGridViewTextBoxColumn
            // 
            this.libstockDataGridViewTextBoxColumn.DataPropertyName = "lib_stock";
            this.libstockDataGridViewTextBoxColumn.HeaderText = "Stock";
            this.libstockDataGridViewTextBoxColumn.Name = "libstockDataGridViewTextBoxColumn";
            this.libstockDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 490);
            this.Controls.Add(this.Tabs);
            this.Name = "FormPrincipal";
            this.Text = "FormPrincipal";
            this.Load += new System.EventHandler(this.FormPrincipal_Load);
            this.Tabs.ResumeLayout(false);
            this.Home.ResumeLayout(false);
            this.Home.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.FAQ.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.GestorUsuarios.ResumeLayout(false);
            this.GestorLibros.ResumeLayout(false);
            this.GestorAutores.ResumeLayout(false);
            this.Stock.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.librosBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistemalibroscocinaDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sistema_libros_cocinaDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.librosBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox Usuario;
        private System.Windows.Forms.Button Loggin;
        private System.Windows.Forms.Button registrarse;
        private System.Windows.Forms.Button lista_libros;
        private System.Windows.Forms.Button mas_vendidos;
        private System.Windows.Forms.Button add_libro;
        private System.Windows.Forms.Button borrar_libro;
        private System.Windows.Forms.Button agregar_aut;
        private System.Windows.Forms.Button del_autor;
        private System.Windows.Forms.Button eliminar_usuario;
        private System.Windows.Forms.Button Agregar_FAQ;
        private System.Windows.Forms.Label EstadoLoggin;
        private System.Windows.Forms.TabControl Tabs;
        private System.Windows.Forms.TabPage Home;
        private System.Windows.Forms.TabPage FAQ;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox pregBox;
        private System.Windows.Forms.Button Elegir;
        private System.Windows.Forms.Button Desloggear;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.DataGridView dataGrid;
        private System.Windows.Forms.TabPage GestorUsuarios;
        private System.Windows.Forms.TabPage GestorLibros;
        private System.Windows.Forms.TabPage GestorAutores;
        private System.Windows.Forms.TextBox busq_text;
        private System.Windows.Forms.Button BUSCAR;
        private System.Windows.Forms.TabPage Stock;
        private System.Windows.Forms.BindingSource sistemalibroscocinaDataSetBindingSource;
        private sistema_libros_cocinaDataSet sistema_libros_cocinaDataSet;
        private System.Windows.Forms.BindingSource librosBindingSource;
        private sistema_libros_cocinaDataSetTableAdapters.librosTableAdapter librosTableAdapter;
        private System.Windows.Forms.BindingSource librosBindingSource1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn libisbnDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn libnombreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn libstockDataGridViewTextBoxColumn;
    }
}