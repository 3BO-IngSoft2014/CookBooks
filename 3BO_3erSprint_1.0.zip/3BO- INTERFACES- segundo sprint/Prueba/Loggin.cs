﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Prueba
{
    class Loggin
    {
        String usuario, contraseña;
        Boolean isAdmin;

        public  Loggin(String Usuario, String Contraseña) 
        {
            this.usuario = Usuario;
            this.contraseña = Contraseña;
            this.isAdmin = false;

        }
       public Boolean loggear()
        {

            string conexion = "Server=localhost;Database=sistema_libros_cocina;User ID=root;Password=123456;Pooling=false;";
	        MySqlConnection conn = new MySqlConnection(conexion);
	        conn.Open();

            string query = "Select nombreUsuario , pass , isAdmin From sistema_libros_cocina.usuario Where nombreUsuario = '" + this.usuario + "' AND pass = '" + this.contraseña + "';";
            String[] listausuarios = new String[3];
         //   MessageBox.Show(query);
	        MySqlCommand mycomand = new MySqlCommand();
            mycomand.Connection = conn;
            mycomand.CommandText = query;
  /*          mycomand.Parameters.AddWithValue("?usu", this.usuario);
	        mycomand.Parameters.AddWithValue("?pwd", this.contraseña);
	*/
	        MySqlDataReader myreader = mycomand.ExecuteReader();
	        
            

	        if (myreader.HasRows)
	        {
                while (myreader.Read())
                {
                    myreader.Read();
                   
                    listausuarios[0] = (myreader[0].ToString());
               //     MessageBox.Show(myreader[0].ToString());
                    listausuarios[1] = (myreader[1].ToString());
                 //   MessageBox.Show(myreader[1].ToString());
                    listausuarios[2] = (myreader[2].ToString());
                }
	        }
            
            if (listausuarios[0] != null && listausuarios[0] != null)
            {
                MessageBox.Show("Usted se ha loggeado como: " + listausuarios[0]);
                if (listausuarios[2].ToString().Equals("Y"))
                    this.isAdmin = true;

                return true;
            }
            else
            {
                MessageBox.Show("Usuario o contraseña invalidos");
                return false;
            }
        }
       public Boolean isAdministrador()
       { return this.isAdmin; }


    }
}
