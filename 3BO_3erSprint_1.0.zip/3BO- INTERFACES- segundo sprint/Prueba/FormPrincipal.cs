﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Prueba
{
    public partial class FormPrincipal : Form
    {
        public Boolean isRegistrado = false ;
        public Boolean isAdmin = false;
        String usuario;

        public FormPrincipal()
        {

            InitializeComponent();
            this.Desloggear.Hide();
            this.Cargar_listadoLibros();
            hide_tabs();


        }
        private void show_tabs() 
        {
            if (this.isRegistrado && this.isAdmin) 
            {
                this.GestorAutores.Parent = this.Tabs;
                this.GestorLibros.Parent = this.Tabs;
                this.GestorUsuarios.Parent = this.Tabs;
            }

        }
        private void hide_tabs() 
        {
            if (!isRegistrado) 
            {
                this.isAdmin = false;
                this.GestorAutores.Parent = null;
                this.GestorLibros.Parent = null;
                this.GestorUsuarios.Parent = null;
            }
        }

        private void registrarse_Click(object sender, EventArgs e)
        {
            AgregarUsuario usernuevo = new AgregarUsuario();
            usernuevo.ShowDialog();
        }

        private void Loggin_Click(object sender, EventArgs e)
        {
            Loggin log = new Loggin(this.Usuario.Text, this.password.Text);
            Boolean registro=log.loggear();
            if (registro)
            {
                this.isRegistrado = true;
                this.isAdmin = log.isAdministrador();
                this.usuario = this.Usuario.Text;
                this.Usuario.Hide();
                this.password.Hide();
                this.registrarse.Hide();
                this.Desloggear.Show();
                this.Usuario.Text = "ingrese usuario";
                this.password.Text = "ingrese pass";
                this.EstadoLoggin.Text = "loggeado como:" + this.usuario;
                this.EstadoLoggin.ForeColor = Color.Green;
                
                this.show_tabs();
                
            }
            else
                this.isRegistrado = false;

            
            //MessageBox.Show("creo el object");
           
            //MessageBox.Show( log.loggear().ToString());

        }

        private void Stock_Click(object sender, EventArgs e)
        {
            BusquedaPorBuscador buscador = new BusquedaPorBuscador();
            buscador.ShowDialog();
        }

        private void lista_libros_Click(object sender, EventArgs e)
        {
            ListadoLibros libros = new ListadoLibros();
            libros.ShowDialog();
        }

        private void mas_vendidos_Click(object sender, EventArgs e)
        {
            LibrosMasVendidos masvendidos = new LibrosMasVendidos();
            masvendidos.ShowDialog();
        }

        private void add_libro_Click(object sender, EventArgs e)
        {
            AgregarLibros addlibro = new AgregarLibros();
            addlibro.ShowDialog();
        }

        private void borrar_libro_Click(object sender, EventArgs e)
        {
            BorrarLibro borrarlibro = new BorrarLibro();
            borrarlibro.ShowDialog();
        }

        private void agregar_aut_Click(object sender, EventArgs e)
        {
            AgregarAutor aut = new AgregarAutor();
            aut.ShowDialog();

        }

        private void del_autor_Click(object sender, EventArgs e)
        {
            EliminarAutor delautor = new EliminarAutor();
            delautor.ShowDialog();
        }

        private void eliminar_usuario_Click(object sender, EventArgs e)
        {
            EliminarUsuario delusu = new EliminarUsuario();
            delusu.ShowDialog();
        }

        private void Agregar_FAQ_Click(object sender, EventArgs e)
        {
            AgregarPreguntasMasFrecuentes faq = new AgregarPreguntasMasFrecuentes();
            faq.ShowDialog();
        }

        private void ver_FAQs_Click(object sender, EventArgs e)
        {
            VerFAQ vfaq = new VerFAQ();
            vfaq.ShowDialog();
        }

        private void FAQ_Click(object sender, EventArgs e)
        {

        }

        private void Tabs_Layout(object sender, LayoutEventArgs e)
        {
            
        }

        private void pregBox_Enter(object sender, EventArgs e)
        {
            try
            {
                
                string myConnection = "datasource = localhost;username=root;password=123456";

                String sQuery = "SELECT * FROM sistema_libros_cocina.preguntasyrespuestas; ";// WHERE preg = '" + myString + "' ;";


                MySqlConnection myConn = new MySqlConnection(myConnection);

                MySqlCommand command = new MySqlCommand(sQuery, myConn);

                //MySqlDataAdapter sda = new MySqlDataAdapter();
                MySqlDataReader myReader;
                myConn.Open();
                //sda.SelectCommand = command;
                myReader = command.ExecuteReader();
                
                while (myReader.Read())
                {
                    String sName = myReader.GetString("preg");
                    this.pregBox.Items.Add(sName);

                }﻿
                


                myConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }﻿
        }

        private void pregBox_Leave(object sender, EventArgs e)
        {
            this.pregBox.Items.Clear();
        }

        private void Elegir_Click(object sender, EventArgs e)
        {
            try
            {
                string myConnection = "datasource = localhost;username=root;password=123456";
                string myString = this.pregBox.Text;
                String sQuery = "SELECT resp FROM sistema_libros_cocina.preguntasyrespuestas WHERE preg = '" + myString + "' ;";


                MySqlConnection myConn = new MySqlConnection(myConnection);

                MySqlCommand command = new MySqlCommand(sQuery, myConn);

                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = command;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                this.dataGridView1.DataSource = bSource;
                sda.Update(dbdataset);

                //myConn.Open();




                //myConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }﻿
        }

        private void Desloggear_Click(object sender, EventArgs e)
        {
            if (this.isRegistrado) 
            {
                this.isRegistrado = false;
                this.EstadoLoggin.Text = "Registrese o ingrese" ;
                this.usuario = "";
                this.Usuario.Show();
                this.password.Show();
                this.registrarse.Show();
                this.Desloggear.Hide();
                this.hide_tabs();
            }
        }

        private void BUSCAR_Click(object sender, EventArgs e)
        {
            try
            {
                string myConnection = "datasource = localhost;username=root;password=123456";
                string myString = this.busq_text.Text;

                if (myString.Equals(""))
                {
                    this.Cargar_listadoLibros();
                }
                else
                {
                    String sQuery = "SELECT li.lib_nombre as Titulo, au.aut_nombre as Autor , li.lib_isbn as ISBN FROM sistema_libros_cocina.autores_libros al " + " INNER JOIN sistema_libros_cocina.libros li ON al.lib_isbn = li.lib_isbn" +
                        " INNER JOIN sistema_libros_cocina.autores au ON al.aut_id = au.aut_id" +
                        " WHERE (au.aut_nombre LIKE '%" + myString + "%') OR (li.lib_nombre LIKE '%" + myString + "%')" + ";"; // + myString + "';"; // + " %'); "; // +this.busq_text.Text + " ' ;"; // " %';" ;//=' " + this.busq_text.Text + "  ' or c.nombreL = '" + this.busq_text.Text + " ' ;";


                    MySqlConnection myConn = new MySqlConnection(myConnection);

                    MySqlCommand command = new MySqlCommand(sQuery, myConn);

                    MySqlDataAdapter sda = new MySqlDataAdapter();
                    sda.SelectCommand = command;
                    DataTable dbdataset = new DataTable();
                    sda.Fill(dbdataset);
                    BindingSource bSource = new BindingSource();

                    bSource.DataSource = dbdataset;
                    this.dataGrid.DataSource = bSource;
                    sda.Update(dbdataset);

                }

                //myConn.Open();




                //myConn.Close();}
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }﻿
        }
        private void Cargar_listadoLibros ()
        {
            try
            {
                string myConnection = "datasource = localhost;username=root;password=123456";

                String sQuery = "SELECT li.lib_isbn as ISBN, li.lib_Nombre as Titulo, au.aut_nombre As Autor,  li.lib_editorial as Editorial," +
               "li.lib_edicion as Edicion, li.lib_precio as Precio" +
               " FROM sistema_libros_cocina.libros li INNER JOIN sistema_libros_cocina.autores_libros al ON al.lib_isbn=li.lib_isbn "+
               "INNER JOIN sistema_libros_cocina.autores au ON au.aut_id = al.aut_id ;"; // falta lib_Stock


                MySqlConnection myConn = new MySqlConnection(myConnection);

                MySqlCommand command = new MySqlCommand(sQuery, myConn);

                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = command;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGrid.DataSource = bSource;
                sda.Update(dbdataset);

                //myConn.Open();




                //myConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }﻿
        }

        private void Home_Enter(object sender, EventArgs e)
        {
            this.Cargar_listadoLibros();
        }

        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'sistema_libros_cocinaDataSet.libros' Puede moverla o quitarla según sea necesario.
            this.librosTableAdapter.Fill(this.sistema_libros_cocinaDataSet.libros);
            // TODO: esta línea de código carga datos en la tabla 'sistema_libros_cocinaDataSet.libros' Puede moverla o quitarla según sea necesario.
            this.librosTableAdapter.Fill(this.sistema_libros_cocinaDataSet.libros);

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.librosTableAdapter.FillBy(this.sistema_libros_cocinaDataSet.libros);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
