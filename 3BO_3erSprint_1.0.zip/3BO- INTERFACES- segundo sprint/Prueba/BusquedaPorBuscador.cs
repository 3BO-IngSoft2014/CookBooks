﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Prueba
{
    public partial class BusquedaPorBuscador : Form
    {
        public BusquedaPorBuscador()
        {
            InitializeComponent();
        }

        private void BUSCAR_Click(object sender, EventArgs e)
        {
            try
            {
                string myConnection = "datasource = localhost;username=root;password=123456";
                string myString = this.busq_text.Text;
                String sQuery = "SELECT li.lib_nombre , au.aut_nombre , li.lib_isbn FROM sistema_libros_cocina.autores_libros al "+" INNER JOIN sistema_libros_cocina.libros li ON al.lib_isbn = li.lib_isbn"+
                    " INNER JOIN sistema_libros_cocina.autores au ON al.aut_id = au.aut_id" +
                    " WHERE (au.aut_nombre LIKE '%" + myString + "%') OR (li.lib_nombre LIKE '%" + myString + "%')"+ ";"; // + myString + "';"; // + " %'); "; // +this.busq_text.Text + " ' ;"; // " %';" ;//=' " + this.busq_text.Text + "  ' or c.nombreL = '" + this.busq_text.Text + " ' ;";

                
                MySqlConnection myConn = new MySqlConnection(myConnection);

                MySqlCommand command = new MySqlCommand(sQuery, myConn);

                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = command;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                this.dataGridView1.DataSource = bSource;
                sda.Update(dbdataset);

                //myConn.Open();




                //myConn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }﻿
        }

        private void busq_text_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
